# modified by Sujith dec 4, 2013   below 2 lines addded
require File.dirname(__FILE__) + "/../../lib/attribute_fu/attribute_fu/associations.rb"
require File.dirname(__FILE__) + "/../../lib/attribute_fu/attribute_fu/associated_form_helper.rb"
#------------------

ActiveRecord::Base.class_eval { include AttributeFu::Associations }
ActionView::Helpers::FormBuilder.class_eval { include AttributeFu::AssociatedFormHelper }
