module AttributeFu #:nodoc:  
end
